package com.eagleteam.knigh.schedule.Object;

import java.util.ArrayList;
import java.util.List;

public class FilterScore {
    private List<Score> listScores;

    public FilterScore(List<Score> listScores) {
        this.listScores = listScores;
    }

    public List<Score> getListScores() {
        return listScores;
    }

    public List<Score> getListScoresByRank(String rank){
        List<Score> listScoresByRank = new ArrayList<>();
        for (int i = 0; i < listScores.size();i++){
            if (listScores.get(i).getXepLoai().endsWith(rank))
                listScoresByRank.add(listScores.get(i));
        }
        return listScoresByRank;
    }
}
