package com.eagleteam.knigh.schedule.Object;

public class Score {
    private String maMon, tenMon, soTinChi;
    private String diemCC, diemThi, diemTB;
    private String xepLoai;

    public Score(String maMon, String tenMon, String soTinChi, String diemCC, String diemThi, String diemTB, String xepLoai) {
        this.maMon = maMon;
        this.tenMon = tenMon;
        this.soTinChi = soTinChi;
        this.diemCC = diemCC;
        this.diemThi = diemThi;
        this.diemTB = diemTB;
        this.xepLoai = xepLoai;
    }


    public String getMaMon() {
        return maMon;
    }

    public void setMaMon(String maMon) {
        this.maMon = maMon;
    }

    public String getTenMon() {
        return tenMon;
    }

    public void setTenMon(String tenMon) {
        this.tenMon = tenMon;
    }

    public String getSoTinChi() {
        return soTinChi;
    }

    public void setSoTinChi(String soTinChi) {
        this.soTinChi = soTinChi;
    }

    public String getDiemCC() {
        return diemCC;
    }

    public void setDiemCC(String diemCC) {
        this.diemCC = diemCC;
    }

    public String getDiemThi() {
        return diemThi;
    }

    public void setDiemThi(String diemThi) {
        this.diemThi = diemThi;
    }

    public String getDiemTB() {
        return diemTB;
    }

    public void setDiemTB(String diemTB) {
        this.diemTB = diemTB;
    }

    public String getXepLoai() {
        return xepLoai;
    }

    public void setXepLoai(String xepLoai) {
        this.xepLoai = xepLoai;
    }
}
