package com.eagleteam.knigh.schedule.Fragment;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.eagleteam.knigh.schedule.Adapter.AdapterSemester;
import com.eagleteam.knigh.schedule.Database.DatabaseSchedule;
import com.eagleteam.knigh.schedule.Object.Semester;
import com.eagleteam.knigh.schedule.Object.Student;
import com.eagleteam.knigh.schedule.R;
import com.eagleteam.knigh.schedule.Until.ConnectServer;
import com.eagleteam.knigh.schedule.Until.ParserJSON;

import org.json.JSONException;

import java.util.List;

import es.dmoral.toasty.Toasty;

public class FragmentLogin extends Fragment implements View.OnClickListener{
    private EditText edtMaSV, edtMatKhau;
    private Button btnDangNhap;
    private DatabaseSchedule databaseSchedule;
    private SharedPreferences sharedPreferences;
    private TextView tvHoTen, tvLop;
    private NavigationView navMenu;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login, container, false);

        getActivity().setTitle("Đăng nhập");
        edtMaSV = view.findViewById(R.id.edtMaSV);
        edtMatKhau = view.findViewById(R.id.edtMatKhau);
        btnDangNhap = view.findViewById(R.id.btnDangNhap);
        databaseSchedule = new DatabaseSchedule(getActivity());
        sharedPreferences = getActivity().getSharedPreferences("config_login", getActivity().MODE_PRIVATE);

        btnDangNhap.setOnClickListener(this);

        navMenu = getActivity().findViewById(R.id.nav_menu);
        View viewMenu = navMenu.getHeaderView(0);
        tvHoTen = viewMenu.findViewById(R.id.tvHoTen);
        tvLop = viewMenu.findViewById(R.id.tvLop);

        return view;
    }

    @Override
    public void onClick(View view) {
       if (isNetworkConnected() == true){
           if (edtMaSV.getText().toString().trim().isEmpty() == false && edtMatKhau.getText().toString().trim().isEmpty() == false){
               String username = edtMaSV.getText().toString().trim().toUpperCase();
               String password = edtMatKhau.getText().toString().trim();
               final ProgressDialog progressDialog = new ProgressDialog(getActivity());
               progressDialog.setCancelable(false);
               progressDialog.setMessage("Đang đăng nhập...");
               progressDialog.show();
               new ConnectServer().getJSONLogin(getActivity(), username, password, new ConnectServer.VolleyCallBack() {
                   @Override
                   public void getJSON(String json) {
                       progressDialog.dismiss();
                       if (json.equals("false"))
                           Toasty.error(getActivity(), "Sai tên đăng nhập hoặc mật khẩu", Toast.LENGTH_SHORT).show();
                       else{
                           MenuItem menuItem = navMenu.getMenu().getItem(6);
                           menuItem.setTitle("Đăng xuất");
                           final SharedPreferences.Editor editor = sharedPreferences.edit();
                           final ProgressDialog progressDialog1 = new ProgressDialog(getActivity());
                           progressDialog1.setMessage("Đang lấy danh sách kỳ học...");
                           progressDialog1.setCancelable(false);
                           progressDialog1.show();
                           editor.putString("access-token", json);
                           new ConnectServer().getJSONProfileStudent(getActivity(), json, new ConnectServer.VolleyCallBack() {
                               @Override
                               public void getJSON(String json) throws JSONException {
                                   Student student = new ParserJSON(json).getProfileStudent();
                                   editor.putString("MaSV", student.getMaSinhVien());
                                   editor.putString("HoTen", student.getHoTen());
                                   editor.putString("Lop", student.getLop());
                                   editor.apply();
                                   tvHoTen.setText(sharedPreferences.getString("HoTen", "Eagle Team"));
                                   tvLop.setText(sharedPreferences.getString("Lop", ""));
                               }
                           });
                           new ConnectServer().getJSONSemester(getActivity(), json, new ConnectServer.VolleyCallBack() {
                               @Override
                               public void getJSON(String json) throws JSONException {
                                   LayoutInflater layoutInflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                                   View view = layoutInflater.inflate(R.layout.layout_dialog_semester, null, false);
                                   List<Semester> listSemesters = new ParserJSON(json).getListSemester();
                                   RecyclerView recyclerView = view.findViewById(R.id.recyclerViewSemester);
                                   recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
                                   AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                                   builder.setView(view);
                                   builder.setCancelable(false);
                                   AlertDialog alertDialog = builder.create();
                                   recyclerView.setAdapter(new AdapterSemester(getActivity(), listSemesters, alertDialog));
                                   progressDialog1.dismiss();
                                   alertDialog.show();
                                   databaseSchedule.deleteListSchedule();
                                   databaseSchedule.deleteScore();
                               }
                           });
                       }
                   }
               });
           }
       }else
           Toasty.warning(getActivity(), "Không có kết nối mạng!", Toast.LENGTH_SHORT).show();
    }
    public boolean isNetworkConnected() {
        ConnectivityManager cm = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo() != null;
    }
}
