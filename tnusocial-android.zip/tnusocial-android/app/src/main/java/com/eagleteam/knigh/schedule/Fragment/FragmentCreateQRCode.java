package com.eagleteam.knigh.schedule.Fragment;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.eagleteam.knigh.schedule.R;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import es.dmoral.toasty.Toasty;

public class FragmentCreateQRCode extends Fragment {
    private EditText edtMaSV;
    private TextView tvMaSV;
    private ImageView imageQRCode;
    private Button btnTaoMa;
    private MultiFormatWriter multiFormatWriter;
    private SharedPreferences sharedPreferencesLogin;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_create_qr_code, container, false);

        getActivity().setTitle("Tạo mã QR");
        edtMaSV = view.findViewById(R.id.edtMaSV);
        tvMaSV = view.findViewById(R.id.tvMaSV);
        imageQRCode = view.findViewById(R.id.imageQRCode);
        btnTaoMa = view.findViewById(R.id.btnCreateQRCode);
        multiFormatWriter = new MultiFormatWriter();
        sharedPreferencesLogin = getActivity().getSharedPreferences("config_login", Context.MODE_PRIVATE);
        if (sharedPreferencesLogin.getString("MaSV", "").trim().isEmpty() == false) {
            try {
                String text = sharedPreferencesLogin.getString("MaSV", "");
                BitMatrix bitMatrix = multiFormatWriter.encode(text, BarcodeFormat.QR_CODE, 400, 400);
                BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
                Bitmap bitmap = barcodeEncoder.createBitmap(bitMatrix);
                imageQRCode.setImageBitmap(bitmap);
                tvMaSV.setText(text);
            } catch (WriterException e) {
                Toasty.error(getActivity(), "Lỗi!");
            }
        }

        btnTaoMa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (edtMaSV.getText().toString().trim().isEmpty() == false) {
                    try {
                        String text = edtMaSV.getText().toString();
                        BitMatrix bitMatrix = multiFormatWriter.encode(text, BarcodeFormat.QR_CODE, 400, 400);
                        BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
                        Bitmap bitmap = barcodeEncoder.createBitmap(bitMatrix);
                        imageQRCode.setImageBitmap(bitmap);
                        tvMaSV.setText(text);
                    } catch (WriterException e) {
                        Toasty.error(getActivity(), "Lỗi!");
                    }
                }
            }
        });
        return view;
    }
}
