package com.eagleteam.knigh.schedule.Adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.eagleteam.knigh.schedule.Object.Schedule;
import com.eagleteam.knigh.schedule.R;

import java.util.List;

public class AdapterSchedule extends RecyclerView.Adapter<AdapterSchedule.ViewHolder> {
    private Context context;
    private List<Schedule> listSchedules;

    public AdapterSchedule(Context context, List<Schedule> listSchedules) {
        this.context = context;
        this.listSchedules = listSchedules;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.layout_item_schedule, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        viewHolder.tvMonHoc.setVisibility(View.VISIBLE);
        viewHolder.tvThoiGian.setVisibility(View.VISIBLE);
        viewHolder.tvDiaDiem.setVisibility(View.VISIBLE);
        viewHolder.tvGiaoVien.setVisibility(View.VISIBLE);
        viewHolder.tvSoBaoDanh.setVisibility(View.VISIBLE);
        if (listSchedules.get(i).getSoBaoDanh().isEmpty() == true) {
            viewHolder.tvMonHoc.setText("Môn học: " + listSchedules.get(i).getTenMon());
            viewHolder.tvSoBaoDanh.setVisibility(View.GONE);
            viewHolder.tvThoiGian.setText("Thời gian: " + listSchedules.get(i).getThoiGian());
            viewHolder.tvDiaDiem.setText("Địa điểm: " + listSchedules.get(i).getDiaDiem());
            viewHolder.tvGiaoVien.setText("Giáo viên: " + listSchedules.get(i).getGiaoVien());
        }
        if (listSchedules.get(i).getSoBaoDanh().isEmpty() == false) {
            viewHolder.tvMonHoc.setText("Môn thi: " + listSchedules.get(i).getTenMon());
            viewHolder.tvSoBaoDanh.setVisibility(View.VISIBLE);
            viewHolder.tvSoBaoDanh.setText("Số báo danh: " + listSchedules.get(i).getSoBaoDanh());
            viewHolder.tvThoiGian.setText("Thời gian: " + listSchedules.get(i).getThoiGian());
            viewHolder.tvDiaDiem.setText("Địa điểm: " + listSchedules.get(i).getDiaDiem());
            viewHolder.tvGiaoVien.setText("Hình thức: " + listSchedules.get(i).getHinhThuc());
        }
        if (listSchedules.get(i).getThoiGian().isEmpty() == true) {
            viewHolder.tvMonHoc.setText("Tiêu đề: " + listSchedules.get(i).getMaMon());
            viewHolder.tvSoBaoDanh.setVisibility(View.GONE);
            viewHolder.tvThoiGian.setText("Nội dung: " + listSchedules.get(i).getTenMon());
            viewHolder.tvDiaDiem.setVisibility(View.GONE);
            viewHolder.tvGiaoVien.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return listSchedules.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView tvMonHoc, tvThoiGian, tvDiaDiem, tvGiaoVien, tvSoBaoDanh;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvMonHoc = itemView.findViewById(R.id.tvMonHoc);
            tvThoiGian = itemView.findViewById(R.id.tvThoiGian);
            tvDiaDiem = itemView.findViewById(R.id.tvDiaDiem);
            tvGiaoVien = itemView.findViewById(R.id.tvGiaoVien);
            tvSoBaoDanh = itemView.findViewById(R.id.tvSoBaoDanh);
        }
    }
}
