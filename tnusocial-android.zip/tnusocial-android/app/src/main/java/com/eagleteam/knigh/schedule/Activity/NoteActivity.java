package com.eagleteam.knigh.schedule.Activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.eagleteam.knigh.schedule.Adapter.AdapterNote;
import com.eagleteam.knigh.schedule.Database.DatabaseSchedule;
import com.eagleteam.knigh.schedule.Fragment.FragmentSchedule;
import com.eagleteam.knigh.schedule.Object.Schedule;
import com.eagleteam.knigh.schedule.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import es.dmoral.toasty.Toasty;

public class NoteActivity extends AppCompatActivity implements View.OnClickListener{
    private Toolbar toolbar;
    private RecyclerView recyclerView;
    private AlertDialog dialogAddNote;
    private AlertDialog.Builder builderDialog;
    private DatePickerDialog datePickerDialog;
    private EditText edtTitle, edtContent;
    private TextView tvDate;
    private DatabaseSchedule databaseSchedule;
    private Calendar calendar = Calendar.getInstance();
    private AdapterNote adapterNote;
    private List<Schedule> listSchedules;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note);
        toolbar = findViewById(R.id.toolbarNote);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        databaseSchedule = new DatabaseSchedule(NoteActivity.this);
        recyclerView = findViewById(R.id.recyclerViewNote);

        listSchedules = databaseSchedule.getListNote();
        adapterNote = new AdapterNote(NoteActivity.this, listSchedules, databaseSchedule);
        recyclerView.setLayoutManager(new LinearLayoutManager(NoteActivity.this));
        recyclerView.setAdapter(adapterNote);

        initDialogAddNote();

        tvDate.setOnClickListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_add_note, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home){
            Intent data = new Intent();
            data.putExtra("data", "Some interesting data!");
            setResult(Activity.RESULT_OK, data);
            finish();
        }
        if (item.getItemId() == R.id.itemAddNote) {
            datePickerDialog = new DatePickerDialog(NoteActivity.this, AlertDialog.THEME_HOLO_LIGHT, new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker datePicker, int year, int month, int date) {
                    month = month + 1;
                    String strDate = year + "-" + month + "-" + date;
                    Date day = new Date();
                    try {
                        day = new SimpleDateFormat("yyyy-MM-dd").parse(strDate);
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    tvDate.setText(new SimpleDateFormat("yyyy-MM-dd").format(day));
                }
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
            dialogAddNote.show();
        }
        return true;
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.tvDate){
            datePickerDialog.show();
        }
    }
    private void initDialogAddNote(){
        builderDialog = new AlertDialog.Builder(NoteActivity.this);
        builderDialog.setCancelable(false);
        builderDialog.setTitle("Thêm ghi chú");
        View viewDialog = LayoutInflater.from(NoteActivity.this).inflate(R.layout.layout_dialog_addnote, null, false);
        edtTitle = viewDialog.findViewById(R.id.edtTitle);
        edtContent = viewDialog.findViewById(R.id.edtContent);
        tvDate = viewDialog.findViewById(R.id.tvDate);
        builderDialog.setView(viewDialog);
        builderDialog.setPositiveButton("Thêm mới", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (edtTitle.getText().toString().trim().isEmpty() == false
                        && edtContent.getText().toString().trim().isEmpty() == false
                        && tvDate.getText().toString().isEmpty() == false){
                    String title = edtTitle.getText().toString().trim();
                    String content = edtContent.getText().toString().trim();
                    String date = tvDate.getText().toString().trim();
                    Schedule schedule = new Schedule(title, content, "", date, "", "", "", "Note", "");
                    databaseSchedule.addNote(schedule);
                    listSchedules.add(schedule);
                    adapterNote.notifyDataSetChanged();
                    Toasty.success(NoteActivity.this, "Thêm thành công", Toast.LENGTH_SHORT).show();
                }
                else
                    Toasty.error(NoteActivity.this, "Thêm thất bại", Toast.LENGTH_SHORT).show();
            }
        });
        builderDialog.setNegativeButton("Hủy bỏ", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        dialogAddNote = builderDialog.create();
    }
    @Override
    public void onBackPressed() {
        setResult(Activity.RESULT_OK);
        super.onBackPressed();
    }
}
