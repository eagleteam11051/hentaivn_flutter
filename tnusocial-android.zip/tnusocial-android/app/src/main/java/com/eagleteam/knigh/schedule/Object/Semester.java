package com.eagleteam.knigh.schedule.Object;

public class Semester {
    private String tenKy, maKy;

    public Semester(String tenKy, String maKy) {
        this.tenKy = tenKy;
        this.maKy = maKy;
    }

    public String getTenKy() {
        return tenKy;
    }

    public void setTenKy(String tenKy) {
        this.tenKy = tenKy;
    }

    public String getMaKy() {
        return maKy;
    }

    public void setMaKy(String maKy) {
        this.maKy = maKy;
    }
}
