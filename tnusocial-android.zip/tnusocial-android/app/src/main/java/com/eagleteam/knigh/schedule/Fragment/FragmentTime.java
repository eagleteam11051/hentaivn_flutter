package com.eagleteam.knigh.schedule.Fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.eagleteam.knigh.schedule.Adapter.AdapterTimeClass;
import com.eagleteam.knigh.schedule.Database.DatabaseSchedule;
import com.eagleteam.knigh.schedule.R;

public class FragmentTime extends Fragment {
    private RecyclerView recyclerView;
    private DatabaseSchedule databaseSchedule;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_time, container, false);
        getActivity().setTitle("Thời gian ra vào lớp");
        recyclerView = view.findViewById(R.id.recyclerViewTime);
        databaseSchedule = new DatabaseSchedule(getActivity());
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(new AdapterTimeClass(getActivity(), databaseSchedule.getListTimeClasses()));
        return view;
    }
}
