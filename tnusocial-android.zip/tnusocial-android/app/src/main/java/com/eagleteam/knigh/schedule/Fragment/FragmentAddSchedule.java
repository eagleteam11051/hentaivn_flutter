package com.eagleteam.knigh.schedule.Fragment;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.eagleteam.knigh.schedule.Database.DatabaseSchedule;
import com.eagleteam.knigh.schedule.Object.Schedule;
import com.eagleteam.knigh.schedule.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import es.dmoral.toasty.Toasty;

public class FragmentAddSchedule extends Fragment implements View.OnClickListener {
    private DatePickerDialog datePickerDialog;
    private DatabaseSchedule databaseSchedule;
    private Calendar calendar;
    private AutoCompleteTextView edtMonHoc;
    private TextView tvNgay;
    private EditText edtTietBatDau, edtTietKetThuc, edtDiaDiem, edtGiaoVien;
    private Button btnConfirm, btnReset;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_addschedule, container, false);

        databaseSchedule = new DatabaseSchedule(getActivity());
        edtMonHoc = view.findViewById(R.id.edtMonHoc);
        edtTietBatDau = view.findViewById(R.id.edtTietBatDau);
        edtTietKetThuc = view.findViewById(R.id.edtTietKetThuc);
        edtDiaDiem = view.findViewById(R.id.edtDiaDiem);
        edtGiaoVien = view.findViewById(R.id.edtGiaoVien);
        tvNgay = view.findViewById(R.id.tvNgay);
        btnConfirm = view.findViewById(R.id.btnConfirm);
        btnReset = view.findViewById(R.id.btnReset);

        calendar = Calendar.getInstance();
        datePickerDialog = new DatePickerDialog(getActivity(), AlertDialog.THEME_HOLO_LIGHT, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int date) {
                month = month+1;
                String strDate = year + "-" + month + "-" + date;
                Date day = new Date();
                try {
                    day = new SimpleDateFormat("yyyy-MM-dd").parse(strDate);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                tvNgay.setText(new SimpleDateFormat("yyyy-MM-dd").format(day));
            }
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.setTitle("Chọn ngày");

        tvNgay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datePickerDialog.show();
            }
        });
        btnConfirm.setOnClickListener(this);
        btnReset.setOnClickListener(this);

        List<String> listNameSubject = databaseSchedule.getListNameSubject();
        edtMonHoc.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, listNameSubject));

        return view;
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.btnConfirm) {
            if (tvNgay.getText().toString().trim().isEmpty() == false && edtMonHoc.getText().toString().trim().isEmpty() == false
                    && edtTietBatDau.getText().toString().trim().isEmpty() == false && edtTietKetThuc.getText().toString().trim().isEmpty() == false
                    && edtDiaDiem.getText().toString().trim().isEmpty() == false) {
                String tenMon, thoiGian = "", ngay, diaDiem, giaoVien;
                int tgBatDau, tgKetThuc;
                tenMon = edtMonHoc.getText().toString().trim();
                ngay = tvNgay.getText().toString().trim();
                diaDiem = edtDiaDiem.getText().toString().trim();
                giaoVien = edtGiaoVien.getText().toString().trim();
                tgBatDau = Integer.parseInt(edtTietBatDau.getText().toString().trim());
                tgKetThuc = Integer.parseInt(edtTietKetThuc.getText().toString().trim());
                if (tgBatDau > tgKetThuc || tgKetThuc > 12)
                    Toasty.warning(getActivity(), "Tiết học không hợp lê!", Toast.LENGTH_SHORT).show();
                else {
                    for (int i = tgBatDau; i <= tgKetThuc; i++) {
                        if (i == tgKetThuc)
                            thoiGian = thoiGian + i;
                        else
                            thoiGian = thoiGian + i + ",";
                    }
                    Schedule schedule = new Schedule("", tenMon, thoiGian, ngay, diaDiem, "", giaoVien, "Note", "");
                    databaseSchedule.addNote(schedule);
                    Toasty.success(getActivity(), "Thêm thành công", Toast.LENGTH_SHORT).show();
                }
            } else
                Toasty.warning(getActivity(), "Hãy nhập đủ thông tin!", Toast.LENGTH_SHORT).show();
        }
        if (view.getId() == R.id.btnReset) {
            edtMonHoc.setText("");
            tvNgay.setText("");
            edtTietBatDau.setText("");
            edtTietKetThuc.setText("");
            edtDiaDiem.setText("");
            edtGiaoVien.setText("");
            edtMonHoc.requestFocus();
        }
    }
}
