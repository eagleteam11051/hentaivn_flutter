package com.eagleteam.knigh.schedule.Adapter;

import android.app.AlertDialog;
import android.support.v4.app.FragmentActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.eagleteam.knigh.schedule.Fragment.FragmentSchedule;
import com.eagleteam.knigh.schedule.Object.Semester;
import com.eagleteam.knigh.schedule.R;

import java.util.List;

public class AdapterSemester extends RecyclerView.Adapter<AdapterSemester.ViewHolder> {
    private FragmentActivity context;
    private List<Semester> listSemesters;
    private SharedPreferences sharedPreferences;
    private AlertDialog alertDialog;

    public AdapterSemester(FragmentActivity context, List<Semester> listSemesters, AlertDialog alertdialog) {
        this.context = context;
        this.listSemesters = listSemesters;
        sharedPreferences = context.getSharedPreferences("config_login", context.MODE_PRIVATE);
        this.alertDialog = alertdialog;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.layout_item_semester, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        viewHolder.tvTenKy.setText("Kỳ học: " + listSemesters.get(i).getTenKy());
    }

    @Override
    public int getItemCount() {
        return listSemesters.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView tvTenKy;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTenKy = itemView.findViewById(R.id.tvTenKy);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            int pos = getLayoutPosition();
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("semester", listSemesters.get(pos).getMaKy());
            editor.commit();
            FragmentSchedule fragment = new FragmentSchedule();
            context.getSupportFragmentManager().beginTransaction().replace(R.id.frameLayoutMain, fragment).commit();
            alertDialog.dismiss();
        }

    }
}
