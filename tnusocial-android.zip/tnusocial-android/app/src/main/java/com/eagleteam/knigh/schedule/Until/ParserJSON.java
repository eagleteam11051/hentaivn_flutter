package com.eagleteam.knigh.schedule.Until;

import android.util.Log;

import com.eagleteam.knigh.schedule.Object.Schedule;
import com.eagleteam.knigh.schedule.Object.Score;
import com.eagleteam.knigh.schedule.Object.Semester;
import com.eagleteam.knigh.schedule.Object.Student;
import com.eagleteam.knigh.schedule.Object.Subject;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class ParserJSON {
    private String data;

    public ParserJSON(String data) {
        this.data = data;
    }
    public List<Semester> getListSemester() throws JSONException {
        List<Semester> listSemesters = new ArrayList<>();
        JSONArray jsonArray = new JSONArray(data);
        for (int i = 0;i < 5;i++){
            JSONObject object = jsonArray.getJSONObject(i);
            String maKy = object.getString("MaKy");
            String tenKy = object.getString("TenKy");
            listSemesters.add(new Semester(tenKy, maKy));
        }
        return listSemesters;
    }
    public List<Schedule> getListSchedule(List<Subject> listSubjects) throws JSONException {
        List<Schedule> listSchedules = new ArrayList<>();
        JSONObject jsonObject = new JSONObject(data);
        JSONArray jsonArray = jsonObject.getJSONArray("Entries");
        for (int i = 0;i < jsonArray.length();i++){
            JSONObject object = jsonArray.getJSONObject(i);
            String maMon, tenMon = "", thoiGian, ngay, diaDiem, hinhThuc, giaoVien, loaiLich, soBaoDanh;
            maMon = object.getString("MaMon");
            for (int j = 0;j < listSubjects.size();j++){
                if (maMon.equals(listSubjects.get(j).getMaMon()) == true){
                    tenMon = listSubjects.get(j).getTenMon();
                }
            }
            thoiGian = object.getString("ThoiGian");
            ngay = object.getString("Ngay");
            diaDiem = object.getString("DiaDiem");
            hinhThuc = object.getString("HinhThuc");
            giaoVien = object.getString("GiaoVien");
            loaiLich = object.getString("LoaiLich");
            try {
                soBaoDanh = object.getString("SoBaoDanh");
            }catch (Exception e){
                soBaoDanh = "";
            }
            listSchedules.add(new Schedule(maMon, tenMon, thoiGian, ngay, diaDiem, hinhThuc, giaoVien, loaiLich, soBaoDanh));
        }
        return listSchedules;
    }
    public List<Subject> getListSubject() throws JSONException {
        List<Subject> listSubjects = new ArrayList<>();
        JSONObject jsonObject = new JSONObject(data);
        JSONArray jsonArray = jsonObject.getJSONArray("Subjects");
        for (int i = 0;i < jsonArray.length();i++){
            JSONObject object = jsonArray.getJSONObject(i);
            String maMon, tenMon;
            maMon = object.getString("MaMon");
            tenMon = object.getString("TenMon");
            listSubjects.add(new Subject(maMon, tenMon));
        }
        return listSubjects;
    }
    public Student getProfileStudent() throws JSONException {
        JSONObject object = new JSONObject(data);
        String maSinhVien, hoTen, nienKhoa, lop, nganh, truong, heDaoTao;
        maSinhVien = object.getString("MaSinhVien");
        hoTen = object.getString("HoTen");
        nienKhoa = object.getString("NienKhoa");
        lop = object.getString("Lop");
        nganh = object.getString("Nganh");
        truong = object.getString("Truong");
        heDaoTao = object.getString("HeDaoTao");
        return new Student(maSinhVien, hoTen, nienKhoa, lop, nganh, truong, heDaoTao);
    }
    public List<Score> getListScores(List<Subject> listSubjects) throws JSONException {
        List<Score> listScores = new ArrayList<>();
        JSONObject jsonObject = new JSONObject(data);
        JSONArray jsonArray = jsonObject.getJSONArray("Entries");
        for (int i = 0;i < jsonArray.length();i++){
            JSONObject object = jsonArray.getJSONObject(i);
            String maMon, tenMon = "", soTinChi = "", diemCC, diemThi, diemTB, xepLoai;
            maMon = object.getString("MaMon");
            for (int j = 0;j < listSubjects.size();j++){
                if (listSubjects.get(j).getMaMon().equals(maMon) == true){
                    tenMon = listSubjects.get(j).getTenMon();
                    soTinChi = listSubjects.get(j).getSoTinChi();
                }
            }
            diemCC = object.getString("CC");
            diemThi = object.getString("THI");
            diemTB = object.getString("TKHP");
            xepLoai = object.getString("DiemChu");
            listScores.add(new Score(maMon, tenMon, soTinChi, diemCC, diemThi, diemTB, xepLoai));
        }
        return listScores;
    }
    public List<String> getInfoScore() throws JSONException {
        JSONObject jsonObject = new JSONObject(data);
        List<String> listInfos = new ArrayList<>();
        listInfos.add(String.valueOf(jsonObject.getInt("TongTC")));
        listInfos.add(String.valueOf(jsonObject.getInt("STCTD")));
        listInfos.add(String.valueOf(jsonObject.getInt("STCTLN")));
        listInfos.add(String.valueOf(jsonObject.getDouble("DTBC")));
        listInfos.add(String.valueOf(jsonObject.getDouble("DTBCQD")));
        listInfos.add(String.valueOf(jsonObject.getInt("SoMonKhongDat")));
        listInfos.add(String.valueOf(jsonObject.getInt("SoTCKhongDat")));
        return listInfos;
    }
    public List<Subject> getListSubjectsScore() throws JSONException {
        List<Subject> listSubjects = new ArrayList<>();
        JSONObject jsonObject = new JSONObject(data);
        JSONArray jsonArray = jsonObject.getJSONArray("Subjects");
        for (int i = 0;i < jsonArray.length();i++){
            JSONObject object = jsonArray.getJSONObject(i);
            String maMon, tenMon, soTinChi;
            maMon = object.getString("MaMon");
            tenMon = object.getString("TenMon");
            soTinChi = object.getString("SoTinChi");
            listSubjects.add(new Subject(maMon, tenMon, soTinChi));
        }
        return listSubjects;
    }
}
