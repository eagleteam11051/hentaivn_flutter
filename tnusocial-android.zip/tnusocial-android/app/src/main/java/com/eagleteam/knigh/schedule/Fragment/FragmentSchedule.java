package com.eagleteam.knigh.schedule.Fragment;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.eagleteam.knigh.schedule.Activity.NoteActivity;
import com.eagleteam.knigh.schedule.Adapter.AdapterSchedule;
import com.eagleteam.knigh.schedule.Adapter.AdapterSemester;
import com.eagleteam.knigh.schedule.Database.DatabaseSchedule;
import com.eagleteam.knigh.schedule.Object.Schedule;
import com.eagleteam.knigh.schedule.Object.Score;
import com.eagleteam.knigh.schedule.Object.Semester;
import com.eagleteam.knigh.schedule.Object.Subject;
import com.eagleteam.knigh.schedule.R;
import com.eagleteam.knigh.schedule.Until.ConnectServer;
import com.eagleteam.knigh.schedule.Until.ParserJSON;
import com.github.sundeepk.compactcalendarview.CompactCalendarView;
import com.github.sundeepk.compactcalendarview.domain.Event;

import org.json.JSONException;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import es.dmoral.toasty.Toasty;
import io.github.kobakei.materialfabspeeddial.FabSpeedDial;

public class FragmentSchedule extends Fragment implements FabSpeedDial.OnMenuItemClickListener {
    private TextView tvThangNam, tvDate;
    private EditText edtTitle, edtContent;
    private RecyclerView recyclerView;
    private CompactCalendarView calendarLichHoc;
    private SharedPreferences sharedPreferencesLogin;
    private ProgressDialog progressDialog;
    private DatabaseSchedule databaseSchedule;
    private FabSpeedDial fabSpeedDial;
    private AlertDialog dialogAddNote;
    private AlertDialog.Builder builderDialog;
    private Calendar calendar;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_schedule, container, false);
        getActivity().setTitle("Lịch cá nhân");
        tvThangNam = view.findViewById(R.id.tvThangNam);
        recyclerView = view.findViewById(R.id.recyclerViewLichHoc);
        calendarLichHoc = view.findViewById(R.id.calendarLichHoc);
        fabSpeedDial = view.findViewById(R.id.fabSchedule);
        databaseSchedule = new DatabaseSchedule(getActivity());
        calendar = Calendar.getInstance();
        sharedPreferencesLogin = getActivity().getSharedPreferences("config_login", getActivity().MODE_PRIVATE);
        if (databaseSchedule.countScheduleTimeTable_ExamTable() == 0 && sharedPreferencesLogin.getString("access-token", "").isEmpty() == false) {
            progressDialog = new ProgressDialog(getActivity());
            progressDialog.setMessage("Đang lưu thời khóa biểu...");
            progressDialog.setCancelable(false);
            progressDialog.show();
            String access_token = sharedPreferencesLogin.getString("access-token", "");
            String semester = sharedPreferencesLogin.getString("semester", "");
            new ConnectServer().getJSONTimeTable(getActivity(), access_token, semester, new ConnectServer.VolleyCallBack() {
                @Override
                public void getJSON(String json) throws JSONException {
                    List<Subject> listSubjects = new ParserJSON(json).getListSubject();
                    databaseSchedule.addListSubject(listSubjects);
                    List<Schedule> listSchedules = new ParserJSON(json).getListSchedule(listSubjects);
                    databaseSchedule.addListSchedule(listSchedules);
                    calendarLichHoc.addEvents(databaseSchedule.getListEventTimeTable());

                }
            });
            new ConnectServer().getJSONExamTable(getActivity(), access_token, semester, new ConnectServer.VolleyCallBack() {
                @Override
                public void getJSON(String json) throws JSONException {
                    List<Subject> listSubjects = new ParserJSON(json).getListSubject();
                    List<Schedule> listExam = new ParserJSON(json).getListSchedule(listSubjects);
                    databaseSchedule.addListSchedule(listExam);
                    calendarLichHoc.addEvents(databaseSchedule.getListEventExamTable());
                    progressDialog.dismiss();
                }
            });
        }
        tvThangNam.setText("Tháng " + new SimpleDateFormat("MM - yyyy").format(Calendar.getInstance().getTime()));
        String[] strs = {"CN", "T2", "T3", "T4", "T5", "T6", "T7"};
        calendarLichHoc.setFirstDayOfWeek(Calendar.SUNDAY);
        calendarLichHoc.setDayColumnNames(strs);
        calendarLichHoc.addEvents(databaseSchedule.getListEventTimeTable());
        calendarLichHoc.addEvents(databaseSchedule.getListEventExamTable());
        calendarLichHoc.addEvents(databaseSchedule.getListEventNote());
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        Date today = calendar.getTime();
        final int currentMonth = calendar.get(Calendar.MONTH) + 1;
        recyclerView.setAdapter(new AdapterSchedule(getActivity(), databaseSchedule.getListScheduleByDate(today)));
        calendarLichHoc.setListener(new CompactCalendarView.CompactCalendarViewListener() {
            @Override
            public void onDayClick(Date dateClicked) {
                List<Schedule> listSchedules = databaseSchedule.getListScheduleByDate(dateClicked);
                recyclerView.setAdapter(new AdapterSchedule(getActivity(), listSchedules));
            }

            @Override
            public void onMonthScroll(Date firstDayOfNewMonth) {
                List<Schedule> listSchedules = databaseSchedule.getListScheduleByDate(firstDayOfNewMonth);
                recyclerView.setAdapter(new AdapterSchedule(getActivity(), listSchedules));
                tvThangNam.setText("Tháng " + new SimpleDateFormat("MM - yyyy").format(firstDayOfNewMonth));
            }
        });

        fabSpeedDial.addOnMenuItemClickListener(this);

        if (databaseSchedule.countScore() == 0) {
            loadMark();
        }

        return view;
    }

    public boolean isNetworkConnected() {
        ConnectivityManager cm = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo() != null;
    }

    @Override
    public void onMenuItemClick(FloatingActionButton miniFab, @Nullable TextView label, int itemId) {
        if (itemId == R.id.itemUpdate) {
            if (sharedPreferencesLogin.getString("access-token", "").isEmpty() == true ||
                    sharedPreferencesLogin.getString("semester", "").isEmpty() == true) {
                Toasty.error(getActivity(), "Bạn chưa đăng nhập", Toast.LENGTH_SHORT).show();
            } else {
                if (isNetworkConnected() == true) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setMessage("Xác nhận cập nhật lịch?");
                    builder.setCancelable(true);
                    builder.setPositiveButton("Đồng ý", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            progressDialog = new ProgressDialog(getActivity());
                            progressDialog.setMessage("Đang lấy danh sách kỳ học...");
                            progressDialog.setCancelable(false);
                            progressDialog.show();
                            databaseSchedule.deleteListTimeTable_ExamTable();
                            calendarLichHoc.removeAllEvents();
                            new ConnectServer().getJSONSemester(getActivity(), sharedPreferencesLogin.getString("access-token", ""), new ConnectServer.VolleyCallBack() {
                                @Override
                                public void getJSON(String json) throws JSONException {
                                    LayoutInflater layoutInflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                                    View view = layoutInflater.inflate(R.layout.layout_dialog_semester, null, false);
                                    List<Semester> listSemesters = new ParserJSON(json).getListSemester();
                                    RecyclerView recyclerView = view.findViewById(R.id.recyclerViewSemester);
                                    recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
                                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                                    builder.setView(view);
                                    AlertDialog alertDialog = builder.create();
                                    recyclerView.setAdapter(new AdapterSemester(getActivity(), listSemesters, alertDialog));
                                    progressDialog.dismiss();
                                    alertDialog.show();
                                }
                            });
                        }
                    });
                    builder.setNegativeButton("Hủy bỏ", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                        }
                    });
                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                } else
                    Toasty.warning(getActivity(), "Không có kết nối mạng!", Toast.LENGTH_SHORT).show();
            }
        }
        if (itemId == R.id.itemAddNote) {
            initDialogAddNote();
        }
    }

    public void loadMark() {
        sharedPreferencesLogin = getActivity().getSharedPreferences("config_login", getActivity().MODE_PRIVATE);
        SharedPreferences sharedPreferencesInfoScore = getActivity().getSharedPreferences("config_infoscore", getActivity().MODE_PRIVATE);
        final SharedPreferences.Editor editor = sharedPreferencesInfoScore.edit();
        new ConnectServer().getJSONScore(getActivity(), sharedPreferencesLogin.getString("access-token", ""), new ConnectServer.VolleyCallBack() {
            @Override
            public void getJSON(String json) throws JSONException {
                ParserJSON parserJSON = new ParserJSON(json);
                List<String> listInfosScore = parserJSON.getInfoScore();
                editor.putString("TongTC", listInfosScore.get(0));
                editor.putString("STCTD", listInfosScore.get(1));
                editor.putString("STCTLN", listInfosScore.get(2));
                editor.putString("DTBC", listInfosScore.get(3));
                editor.putString("DTBCQD", listInfosScore.get(4));
                editor.putString("SoMonKhongDat", listInfosScore.get(5));
                editor.putString("SoTCKhongDat", listInfosScore.get(6));
                editor.apply();
                List<Subject> listSubjects = parserJSON.getListSubjectsScore();
                List<Score> listScores = parserJSON.getListScores(listSubjects);
                databaseSchedule.addListScores(listScores);
            }
        });
    }

    private void initDialogAddNote() {
        builderDialog = new android.app.AlertDialog.Builder(getActivity());
        builderDialog.setCancelable(false);
        builderDialog.setTitle("Thêm ghi chú");
        View viewDialog = LayoutInflater.from(getActivity()).inflate(R.layout.layout_dialog_addnote, null, false);
        edtTitle = viewDialog.findViewById(R.id.edtTitle);
        edtContent = viewDialog.findViewById(R.id.edtContent);
        tvDate = viewDialog.findViewById(R.id.tvDate);
        final DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(), AlertDialog.THEME_HOLO_LIGHT, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int date) {
                month = month + 1;
                String strDate = year + "-" + month + "-" + date;
                Date day = new Date();
                try {
                    day = new SimpleDateFormat("yyyy-MM-dd").parse(strDate);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                tvDate.setText(new SimpleDateFormat("yyyy-MM-dd").format(day));
            }
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        tvDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datePickerDialog.show();
            }
        });
        builderDialog.setView(viewDialog);
        builderDialog.setPositiveButton("Thêm mới", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (edtTitle.getText().toString().trim().isEmpty() == false
                        && edtContent.getText().toString().trim().isEmpty() == false
                        && tvDate.getText().toString().isEmpty() == false) {
                    String title = edtTitle.getText().toString().trim();
                    String content = edtContent.getText().toString().trim();
                    String strDate = tvDate.getText().toString().trim();
                    Schedule schedule = new Schedule(title, content, "", strDate, "", "", "", "Note", "");
                    databaseSchedule.addNote(schedule);
                    Date date = new Date();
                    try {
                        date = new SimpleDateFormat("yyyy-MM-dd").parse(strDate);
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    long milis = date.getTime();
                    calendarLichHoc.addEvent(new Event(Color.YELLOW, milis));
                    Toasty.success(getActivity(), "Thêm thành công", Toast.LENGTH_SHORT).show();
                } else
                    Toasty.error(getActivity(), "Thêm thất bại", Toast.LENGTH_SHORT).show();
            }
        });
        builderDialog.setNegativeButton("Hủy bỏ", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        dialogAddNote = builderDialog.create();
        dialogAddNote.show();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 123) {
            if (resultCode == Activity.RESULT_OK) {
                getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.frameLayoutMain, new FragmentSchedule()).commit();
            }
        }
    }
}
