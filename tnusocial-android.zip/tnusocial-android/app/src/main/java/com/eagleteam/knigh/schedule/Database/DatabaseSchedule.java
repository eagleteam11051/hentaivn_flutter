package com.eagleteam.knigh.schedule.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Color;
import android.support.annotation.Nullable;

import com.eagleteam.knigh.schedule.Object.Schedule;
import com.eagleteam.knigh.schedule.Object.Score;
import com.eagleteam.knigh.schedule.Object.Subject;
import com.eagleteam.knigh.schedule.Object.TimeClass;
import com.github.sundeepk.compactcalendarview.domain.Event;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class DatabaseSchedule extends SQLiteOpenHelper {
    public static String DatabaseSchedule = "database_schedule";
    private static String TableSchedule = "Schedule";
    private static String TableSubject = "Subject";
    private static String TableScore = "Score";
    private static String TableTimeClass = "TimeClass";

    private static String Col_ID = "ID";
    private static String Col_MaMon = "MaMon";
    private static String Col_ThoiGian = "ThoiGian";
    private static String Col_Ngay = "Ngay";
    private static String Col_DiaDiem = "DiaDiem";
    private static String Col_HinhThuc = "HinhThuc";
    private static String Col_GiaoVien = "GiaoVien";
    private static String Col_LoaiLich = "LoaiLich";
    private static String Col_SoBaoDanh = "SoBaoDanh";

    private static String Col_TenMon = "TenMon";
    private static String Col_SoTinChi = "SoTinChi";
    private static String Col_DiemCC = "DiemCC";
    private static String Col_DiemKT = "DiemKT";
    private static String Col_DiemThi = "DiemThi";
    private static String Col_DiemTB = "DiemTB";
    private static String Col_XepLoai = "XepLoai";

    private static String Col_Tiet = "Tiet";
    private static String Col_TgBatDauMuaHe = "TgBatDauMuaHe";
    private static String Col_TgBatDauMuaDong = "TgBatDauMuaDong";
    private static String Col_TgKetThucMuaDong = "TgKetThucMuaDong";
    private static String Col_TgKetThucMuaHe = "TgKetThucMuaHe";
    public DatabaseSchedule(@Nullable Context context) {
        super(context, DatabaseSchedule, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String strCreateTableSchedule = "CREATE TABLE " + TableSchedule + " (" +
                Col_ID + " INTEGER PRIMARY KEY, " +
                Col_MaMon + " TEXT, " +
                Col_TenMon + " TEXT, " +
                Col_ThoiGian + " TEXT, " +
                Col_Ngay + " TEXT, " +
                Col_DiaDiem + " TEXT, " +
                Col_HinhThuc + " TEXT, " +
                Col_GiaoVien + " TEXT, " +
                Col_LoaiLich + " TEXT, " +
                Col_SoBaoDanh + " TEXT)";
        String strCreateTableSubject = "CREATE TABLE " + TableSubject + " (" +
                Col_MaMon + " TEXT PRIMARY KEY, " +
                Col_TenMon + " TEXT)";
        String strCreateTableScore = "CREATE TABLE " + TableScore + " (" +
                Col_MaMon + " TEXT PRIMARY KEY, " +
                Col_TenMon + " TEXT, " +
                Col_SoTinChi + " TEXT, " +
                Col_DiemCC + " TEXT, " +
                Col_DiemThi + " TEXT, " +
                Col_DiemTB + " TEXT, " +
                Col_XepLoai + " TEXT)";
        String strCreateTableTimeClass = "CREATE TABLE " + TableTimeClass + " (" +
                Col_Tiet + " INTEGER PRIMARY KEY, " +
                Col_TgBatDauMuaHe + " TEXT, " +
                Col_TgKetThucMuaHe + " TEXT, " +
                Col_TgBatDauMuaDong + " TEXT, " +
                Col_TgKetThucMuaDong + " TEXT)";
        sqLiteDatabase.execSQL(strCreateTableSchedule);
        sqLiteDatabase.execSQL(strCreateTableSubject);
        sqLiteDatabase.execSQL(strCreateTableScore);
        sqLiteDatabase.execSQL(strCreateTableTimeClass);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TableSchedule);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TableSubject);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TableScore);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TableTimeClass);
        onCreate(sqLiteDatabase);
    }

    public void addNote(Schedule schedule) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(Col_MaMon, schedule.getMaMon());
        values.put(Col_TenMon, schedule.getTenMon());
        values.put(Col_ThoiGian, schedule.getThoiGian());
        values.put(Col_Ngay, schedule.getNgay());
        values.put(Col_DiaDiem, schedule.getDiaDiem());
        values.put(Col_HinhThuc, schedule.getHinhThuc());
        values.put(Col_GiaoVien, schedule.getGiaoVien());
        values.put(Col_LoaiLich, schedule.getLoaiLich());
        values.put(Col_SoBaoDanh, schedule.getSoBaoDanh());
        sqLiteDatabase.insert(TableSchedule, null, values);
        sqLiteDatabase.close();
    }
    public void addListSchedule(List<Schedule> listSchedules) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        for (int i = 0; i < listSchedules.size(); i++) {
            Schedule schedule = listSchedules.get(i);
            ContentValues values = new ContentValues();
            values.put(Col_MaMon, schedule.getMaMon());
            values.put(Col_TenMon, schedule.getTenMon());
            values.put(Col_ThoiGian, schedule.getThoiGian());
            values.put(Col_Ngay, schedule.getNgay());
            values.put(Col_DiaDiem, schedule.getDiaDiem());
            values.put(Col_HinhThuc, schedule.getHinhThuc());
            values.put(Col_GiaoVien, schedule.getGiaoVien());
            values.put(Col_LoaiLich, schedule.getLoaiLich());
            values.put(Col_SoBaoDanh, schedule.getSoBaoDanh());
            sqLiteDatabase.insert(TableSchedule, null, values);
        }
        sqLiteDatabase.close();
    }
    public void addListSubject(List<Subject> listSubjects){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        for (int i = 0; i < listSubjects.size(); i++) {
            Subject subject = listSubjects.get(i);
            ContentValues values = new ContentValues();
            values.put(Col_MaMon, subject.getMaMon());
            values.put(Col_TenMon, subject.getTenMon());
            sqLiteDatabase.insert(TableSubject, null, values);
        }
        sqLiteDatabase.close();
    }
    public void addListTimeClass(List<TimeClass> listTimeClasses){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        for (int i = 0; i < listTimeClasses.size(); i++) {
            TimeClass timeClass  = listTimeClasses.get(i);
            ContentValues values = new ContentValues();
            values.put(Col_Tiet, timeClass.getTiet());
            values.put(Col_TgBatDauMuaHe, timeClass.getTgBatDauMuaHe());
            values.put(Col_TgKetThucMuaHe, timeClass.getTgKetThucMuaHe());
            values.put(Col_TgBatDauMuaDong, timeClass.getTgBatDauMuaDong());
            values.put(Col_TgKetThucMuaDong, timeClass.getTgKetThucMuaDong());
            sqLiteDatabase.insert(TableTimeClass, null, values);
        }
        sqLiteDatabase.close();
    }
    public int countTimeClass(){
        String countQuery = "SELECT  * FROM " + TableTimeClass;
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery(countQuery, null);
        int sl = cursor.getCount();
        cursor.close();
        return sl;
    }
    public List<TimeClass> getListTimeClasses(){
        List<TimeClass> listTimeClasses = new ArrayList<>();
        String strQuery = "SELECT * FROM " + TableTimeClass;
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery(strQuery, null);
        if (cursor.moveToFirst()){
            do {
                int tiet = cursor.getInt(0);
                String tgBatDauMuaHe, tgKetThucMuaHe, tgBatDauMuaDong, tgKetThucMuaDong;
                tgBatDauMuaHe = cursor.getString(1);
                tgKetThucMuaHe = cursor.getString(2);
                tgBatDauMuaDong = cursor.getString(3);
                tgKetThucMuaDong = cursor.getString(4);
                listTimeClasses.add(new TimeClass(tiet, tgBatDauMuaHe, tgKetThucMuaHe, tgBatDauMuaDong, tgKetThucMuaDong));
            } while (cursor.moveToNext());
        }
        return listTimeClasses;
    }
    public List<String> getListNameSubject(){
        List<String> listNameSubjects = new ArrayList<>();
        SQLiteDatabase database = this.getWritableDatabase();
        String strQuery = "SELECT * FROM " + TableSubject;
        Cursor cursor = database.rawQuery(strQuery, null);
        if (cursor.moveToFirst()){
            do {
                listNameSubjects.add(cursor.getString(1));
            }while (cursor.moveToNext());
        }
        return listNameSubjects;
    }
    public int countSchedule() {
        String countQuery = "SELECT  * FROM " + TableSchedule;
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery(countQuery, null);
        int sl = cursor.getCount();
        cursor.close();
        return sl;
    }
    public int countScheduleTimeTable_ExamTable() {
        String countQuery = "SELECT * FROM " + TableSchedule + " WHERE " + TableSchedule + "." + Col_LoaiLich + "=" + "\'" + "LichHoc" + "\'";
        String countQuery1 = "SELECT * FROM " + TableSchedule + " WHERE " + TableSchedule + "." + Col_LoaiLich + "=" + "\'" + "LichThi" + "\'";
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery(countQuery, null);
        Cursor cursor1 = database.rawQuery(countQuery1, null);
        int sl = cursor.getCount();
        int sl1 = cursor1.getCount();
        cursor.close();
        cursor1.close();
        return sl + sl1;
    }
    public void deleteListSchedule() {
        String stringQuery = "DELETE FROM " + TableSchedule;
        String stringQuery1 = "DELETE FROM " + TableSubject;
        SQLiteDatabase database = this.getWritableDatabase();
        database.execSQL(stringQuery);
        database.execSQL(stringQuery1);
        database.close();
    }
    public void deleteListTimeTable_ExamTable() {
        String stringQuery = "DELETE FROM " + TableSchedule + " WHERE " + Col_LoaiLich + "=" + "\'" + "LichHoc" + "\'";
        String stringQuery1 = "DELETE FROM " + TableSchedule + " WHERE " + Col_LoaiLich + "=" + "\'" + "LichThi" + "\'";
        SQLiteDatabase database = this.getWritableDatabase();
        database.execSQL(stringQuery);
        database.execSQL(stringQuery1);
        database.close();
    }

    public List<Event> getListEventTimeTable() {
        List<Event> listEvents = new ArrayList<>();
        String sqlQuery = "SELECT * FROM " + TableSchedule + " WHERE " + TableSchedule + "." + Col_LoaiLich + "=" + "\'" + "LichHoc" + "\'";
        SQLiteDatabase database = this.getReadableDatabase();
        List<String> listDates = new ArrayList<>();
        Cursor cursor = database.rawQuery(sqlQuery, null);
        if (cursor.moveToFirst()) {
            do {
                String stringDate = cursor.getString(4);
                listDates.add(stringDate);
            } while (cursor.moveToNext());
        }
        for (int i = 0; i < listDates.size(); i++) {
            Date date = new Date();
            try {
                date = new SimpleDateFormat("yyyy-MM-dd").parse(listDates.get(i));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            long milis = date.getTime();
            listEvents.add(new Event(Color.BLUE, milis));
        }
        return listEvents;
    }

    public List<Event> getListEventExamTable() {
        List<Event> listEvents = new ArrayList<>();
        String sqlQuery = "SELECT * FROM " + TableSchedule + " WHERE " + TableSchedule + "." + Col_LoaiLich + "=" + "\'" + "LichThi" + "\'";
        SQLiteDatabase database = this.getReadableDatabase();
        List<String> listDates = new ArrayList<>();
        Cursor cursor = database.rawQuery(sqlQuery, null);
        if (cursor.moveToFirst()) {
            do {
                String stringDate = cursor.getString(4);
                listDates.add(stringDate);
            } while (cursor.moveToNext());
        }
        for (int i = 0; i < listDates.size(); i++) {
            Date date = new Date();
            try {
                date = new SimpleDateFormat("yyyy-MM-dd").parse(listDates.get(i));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            long milis = date.getTime();
            listEvents.add(new Event(Color.RED, milis));
        }
        return listEvents;
    }
    public List<Event> getListEventNote(){
        List<Event> listEvents = new ArrayList<>();
        String sqlQuery = "SELECT * FROM " + TableSchedule + " WHERE " + TableSchedule + "." + Col_LoaiLich + "=" + "\'" + "Note" + "\'";
        SQLiteDatabase database = this.getReadableDatabase();
        List<String> listDates = new ArrayList<>();
        Cursor cursor = database.rawQuery(sqlQuery, null);
        if (cursor.moveToFirst()) {
            do {
                String stringDate = cursor.getString(4);
                listDates.add(stringDate);
            } while (cursor.moveToNext());
        }
        for (int i = 0; i < listDates.size(); i++) {
            Date date = new Date();
            try {
                date = new SimpleDateFormat("yyyy-MM-dd").parse(listDates.get(i));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            long milis = date.getTime();
            listEvents.add(new Event(Color.YELLOW, milis));
        }
        return listEvents;
    }
    public List<Schedule> getListScheduleByDate(Date date) {
        String strDate = new SimpleDateFormat("yyyy-MM-dd").format(date);
        String sqlQuery = "SELECT * FROM " + TableSchedule + " WHERE " + TableSchedule + "." + Col_Ngay + "=" + "\'" + strDate + "\'";
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery(sqlQuery, null);
        List<Schedule> listSchedules = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                String maMon, tenMon, thoiGian, ngay, diaDiem, hinhThuc, giaoVien, loaiLich, soBaoDanh;
                maMon = cursor.getString(1);
                tenMon = cursor.getString(2);
                thoiGian = cursor.getString(3);
                ngay = cursor.getString(4);
                diaDiem = cursor.getString(5);
                hinhThuc = cursor.getString(6);
                giaoVien = cursor.getString(7);
                loaiLich = cursor.getString(8);
                soBaoDanh = cursor.getString(9);
                listSchedules.add(new Schedule(maMon, tenMon, thoiGian, ngay, diaDiem, hinhThuc, giaoVien, loaiLich, soBaoDanh));
            } while (cursor.moveToNext());
        }
        for (int i = 0; i < listSchedules.size() - 1; i++) {
            for (int j = i + 1; j < listSchedules.size(); j++) {
                int tam, tam1;
                try {
                    tam = Integer.parseInt(listSchedules.get(i).getThoiGian().substring(0, 1));
                }catch (Exception e){
                    tam = 100;
                }
                try {
                    tam1 = Integer.parseInt(listSchedules.get(j).getThoiGian().substring(0, 1));
                }catch (Exception e){
                    tam1 = 101;
                }
                if (tam > tam1) {
                    Schedule schedule = listSchedules.get(i);
                    listSchedules.set(i, listSchedules.get(j));
                    listSchedules.set(j, schedule);
                }
            }
        }
        return listSchedules;
    }

    public void addListScores(List<Score> listScores) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        for (int i = 0; i < listScores.size(); i++) {
            Score score = listScores.get(i);
            ContentValues values = new ContentValues();
            values.put(Col_MaMon, score.getMaMon());
            values.put(Col_TenMon, score.getTenMon());
            values.put(Col_SoTinChi, score.getSoTinChi());
            values.put(Col_DiemCC, score.getDiemCC());
            values.put(Col_DiemThi, score.getDiemThi());
            values.put(Col_DiemTB, score.getDiemTB());
            values.put(Col_XepLoai, score.getXepLoai());
            sqLiteDatabase.insert(TableScore, null, values);
        }
        sqLiteDatabase.close();
    }

    public int countScore() {
        String countQuery = "SELECT  * FROM " + TableScore;
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery(countQuery, null);
        int sl = cursor.getCount();
        cursor.close();
        return sl;
    }

    public void deleteScore() {
        String stringQuery = "DELETE FROM " + TableScore;
        SQLiteDatabase database = this.getWritableDatabase();
        database.execSQL(stringQuery);
        database.close();
    }

    public List<Score> getListScore() {
        List<Score> listScores = new ArrayList<>();
        String sqlQuery = "SELECT * FROM " + TableScore;
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery(sqlQuery, null);
        if (cursor.moveToFirst()) {
            do {
                String maMon, tenMon, soTinChi, diemCC, diemKi, dienThi, diemTB, xepLoai;
                maMon = cursor.getString(0);
                tenMon = cursor.getString(1);
                soTinChi = cursor.getString(2);
                diemCC = cursor.getString(3);
                dienThi = cursor.getString(4);
                diemTB = cursor.getString(5);
                xepLoai = cursor.getString(6);
                listScores.add(new Score(maMon, tenMon, soTinChi, diemCC, dienThi, diemTB, xepLoai));
            } while (cursor.moveToNext());
        }
        return listScores;
    }
    public List<Schedule> getListNote(){
        List<Schedule> listNotes = new ArrayList<>();
        String sqlQuery = "SELECT * FROM " + TableSchedule + " WHERE " + TableSchedule + "." + Col_LoaiLich + "=" + "\'" + "Note" + "\'";
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery(sqlQuery, null);
        if (cursor.moveToFirst()) {
            do {
                String maMon, tenMon, thoiGian, ngay, diaDiem, hinhThuc, giaoVien, loaiLich, soBaoDanh;
                int id = cursor.getInt(0);
                maMon = cursor.getString(1);
                tenMon = cursor.getString(2);
                thoiGian = cursor.getString(3);
                ngay = cursor.getString(4);
                diaDiem = cursor.getString(5);
                hinhThuc = cursor.getString(6);
                giaoVien = cursor.getString(7);
                loaiLich = cursor.getString(8);
                soBaoDanh = cursor.getString(9);
                listNotes.add(new Schedule(id, maMon, tenMon, thoiGian, ngay, diaDiem, hinhThuc, giaoVien, loaiLich, soBaoDanh));
            } while (cursor.moveToNext());
        }
        Collections.reverse(listNotes);
        return listNotes;
    }
    public void deleteNote(int id){
        String sqlQuery = "DELETE FROM " + TableSchedule + " WHERE " + Col_ID + "=" + "\'" + id + "\'";
        SQLiteDatabase database = this.getWritableDatabase();
        database.execSQL(sqlQuery);
    }
    public void updateNote(Schedule schedule){
        String sqlQuery = "UPDATE " + TableSchedule + " SET " + Col_MaMon + "=" + "\'" + schedule.getMaMon() + "\', "
                + Col_TenMon + "=" + "\'" + schedule.getTenMon() + "\', " + Col_Ngay + "=" + "\'" + schedule.getNgay() + "\'"
                + " WHERE " + Col_ID + "=" + "\'" + schedule.getId() + "\'";
        SQLiteDatabase database = this.getWritableDatabase();
        database.execSQL(sqlQuery);
    }
}