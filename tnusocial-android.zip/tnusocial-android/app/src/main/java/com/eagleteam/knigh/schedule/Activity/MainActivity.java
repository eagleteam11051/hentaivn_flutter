package com.eagleteam.knigh.schedule.Activity;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.eagleteam.knigh.schedule.Database.DatabaseSchedule;
import com.eagleteam.knigh.schedule.Fragment.FragmentCreateQRCode;
import com.eagleteam.knigh.schedule.Fragment.FragmentLogin;
import com.eagleteam.knigh.schedule.Fragment.FragmentSchedule;
import com.eagleteam.knigh.schedule.Fragment.FragmentScore;
import com.eagleteam.knigh.schedule.Fragment.FragmentTime;
import com.eagleteam.knigh.schedule.Object.TimeClass;
import com.eagleteam.knigh.schedule.R;
import com.eagleteam.knigh.schedule.Until.Alarm;

import java.util.ArrayList;
import java.util.List;

import es.dmoral.toasty.Toasty;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private Toolbar toolbar;
    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle drawerToggle;
    private NavigationView nav_menu;
    private SharedPreferences sharedPreferencesLogin;
    private DatabaseSchedule databaseSchedule;
    private MenuItem menuItem;
    private View viewMenuHeader;
    private TextView tvHoTen, tvLop;
    private AlertDialog alertDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //khoi dong alarm thong bao lich hoc
        Alarm.create(this);
        toolbar = findViewById(R.id.toolbarMain);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        drawerLayout = findViewById(R.id.drawerLayout);
        drawerToggle = new ActionBarDrawerToggle(MainActivity.this, drawerLayout, R.string.open, R.string.close);
        drawerLayout.addDrawerListener(drawerToggle);
        drawerToggle.syncState();

        nav_menu = findViewById(R.id.nav_menu);
        nav_menu.setNavigationItemSelectedListener(this);

        viewMenuHeader = nav_menu.getHeaderView(0);
        tvHoTen = viewMenuHeader.findViewById(R.id.tvHoTen);
        tvLop = viewMenuHeader.findViewById(R.id.tvLop);
        menuItem = nav_menu.getMenu().getItem(6);
        databaseSchedule = new DatabaseSchedule(MainActivity.this);
        if (databaseSchedule.countTimeClass() == 0){
            databaseSchedule.addListTimeClass(initListTimeClasses());
        }
        sharedPreferencesLogin = getSharedPreferences("config_login", MODE_PRIVATE);
        if (sharedPreferencesLogin.getString("access-token", "").isEmpty() == true ||
                sharedPreferencesLogin.getString("semester", "").isEmpty() == true) {
            menuItem.setTitle("Đăng nhập");
            FragmentLogin fragment = new FragmentLogin();
            getSupportFragmentManager().beginTransaction().replace(R.id.frameLayoutMain, fragment).commit();
        }
        if (sharedPreferencesLogin.getString("access-token", "").isEmpty() == false) {
            menuItem.setTitle("Đăng xuất");
            FragmentSchedule fragment = new FragmentSchedule();
            getSupportFragmentManager().beginTransaction().replace(R.id.frameLayoutMain, fragment).commit();
            tvHoTen.setText(sharedPreferencesLogin.getString("HoTen", ""));
            tvLop.setText(sharedPreferencesLogin.getString("Lop", ""));
        }


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (drawerToggle.onOptionsItemSelected(item))
            return true;
        return true;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull final MenuItem menuItem) {
        int id = menuItem.getItemId();
        if (id == R.id.itemLichHoc) {
            if (sharedPreferencesLogin.getString("access-token", "").isEmpty() == false) {
                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayoutMain, new FragmentSchedule()).commit();
                drawerLayout.closeDrawers();
            } else
                Toasty.warning(MainActivity.this, "Bạn cần đăng nhập để xem lịch", Toast.LENGTH_SHORT).show();
            ;
        }
        if (id == R.id.itemNote) {
            if (sharedPreferencesLogin.getString("access-token", "").isEmpty() == false) {
                Intent intent = new Intent(MainActivity.this, NoteActivity.class);
                startActivityForResult(intent, 123);
                drawerLayout.closeDrawers();
            } else
                Toasty.warning(MainActivity.this, "Bạn cần đăng nhập để xem ghi chú", Toast.LENGTH_SHORT).show();
            ;
        }
        if (id == R.id.itemThoiGian) {
            getSupportFragmentManager().beginTransaction().replace(R.id.frameLayoutMain, new FragmentTime()).commit();
            drawerLayout.closeDrawers();
        }
        if (id == R.id.itemTraCuuDiem) {
            if (sharedPreferencesLogin.getString("access-token", "").isEmpty() == false) {
                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayoutMain, new FragmentScore()).commit();
                drawerLayout.closeDrawers();
            } else
                Toasty.warning(MainActivity.this, "Bạn cần đăng nhập để xem điểm", Toast.LENGTH_SHORT).show();
        }
        if (id == R.id.itemTaoMa) {
            getSupportFragmentManager().beginTransaction().replace(R.id.frameLayoutMain, new FragmentCreateQRCode()).commit();
            drawerLayout.closeDrawers();
        }
        if(id == R.id.itemSupport){
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/EagleTeam-253603965319573"));
            startActivity(browserIntent);
            drawerLayout.closeDrawers();
        }
        if (id == R.id.itemLogin) {
            if (menuItem.getTitle().equals("Đăng xuất")) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setCancelable(true);
                builder.setMessage("Bạn muốn đăng xuất?");
                builder.setPositiveButton("Đồng ý", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        SharedPreferences sharedPreferencesInfoScore = getSharedPreferences("config_infoscore", MODE_PRIVATE);
                        SharedPreferences.Editor editorLogin = sharedPreferencesLogin.edit();
                        editorLogin.clear().commit();
                        SharedPreferences.Editor editorInfoScore = sharedPreferencesInfoScore.edit();
                        editorInfoScore.clear().commit();
                        databaseSchedule.deleteListSchedule();
                        databaseSchedule.deleteScore();
                        tvHoTen.setText("Bạn chưa đăng nhập");
                        tvLop.setText("");
                        menuItem.setTitle("Đăng nhập");
                        FragmentLogin fragment = new FragmentLogin();
                        getSupportFragmentManager().beginTransaction().replace(R.id.frameLayoutMain, fragment).commit();
                    }
                });
                builder.setNegativeButton("Hủy bỏ", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });
                alertDialog = builder.create();
                alertDialog.show();
            } else {
                FragmentLogin fragment = new FragmentLogin();
                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayoutMain, fragment).commit();
            }
            drawerLayout.closeDrawers();
        }
//        if (id == R.id.itemMessenger){
//            if (sharedPreferencesLogin.getString("access-token", "").isEmpty() == false) {
//                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
//                builder.setCancelable(true);
//                builder.setMessage("Đã tự động sinh mã, bạn hãy dán vào Messenger sau để nhận lịch");
//                builder.setPositiveButton("Chuyển qua Messenger", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialogInterface, int i) {
//                        String stringLogin = "login:" + sharedPreferencesLogin.getString("access-token", "") + ":" + sharedPreferencesLogin.getString("semester", "");
//                        stringLogin = stringLogin.replace("\"", "");
//                        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
//                        ClipData clip = ClipData.newPlainText("Nhận lịch", stringLogin);
//                        clipboard.setPrimaryClip(clip);
//                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://m.me/2191507134472233")));
//                    }
//                });
//                builder.setNegativeButton("Hủy bỏ", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialogInterface, int i) {
//                        dialogInterface.dismiss();
//                    }
//                });
//                alertDialog = builder.create();
//                alertDialog.show();
//
//                drawerLayout.closeDrawers();
//            } else
//                Toasty.warning(MainActivity.this, "Bạn cần đăng nhập!", Toast.LENGTH_SHORT).show();
//        }
        return true;
    }
    public List<TimeClass> initListTimeClasses(){
        List<TimeClass> listTimeClasses = new ArrayList<>();
        listTimeClasses.add(new TimeClass(1, "06:30", "07:20", "06:45", "07:35"));
        listTimeClasses.add(new TimeClass(2, "07:25", "08:15", "07:40", "08:30"));
        listTimeClasses.add(new TimeClass(3, "08:25", "09:15", "08:40", "09:30"));
        listTimeClasses.add(new TimeClass(4, "09:25", "10:15", "09:40", "10:30"));
        listTimeClasses.add(new TimeClass(5, "10:20", "11:10", "10:35", "11:25"));
        listTimeClasses.add(new TimeClass(6, "13:00", "13:50", "13:00", "13:50"));
        listTimeClasses.add(new TimeClass(7, "13:55", "14:45", "13:55", "14:45"));
        listTimeClasses.add(new TimeClass(8, "14:55", "15:45", "14:55", "15:45"));
        listTimeClasses.add(new TimeClass(9, "15:55", "16:45", "15:55", "16:45"));
        listTimeClasses.add(new TimeClass(10, "16:50", "17:40", "16:50", "17:40"));
        listTimeClasses.add(new TimeClass(11, "18:15", "19:05", "18:15", "19:05"));
        listTimeClasses.add(new TimeClass(12, "19:10", "20:00", "19:10", "20:00"));
        return listTimeClasses;
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 123) {
            if (resultCode == Activity.RESULT_OK) {
                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayoutMain, new FragmentSchedule()).commit();
            }
        }
    }
}
