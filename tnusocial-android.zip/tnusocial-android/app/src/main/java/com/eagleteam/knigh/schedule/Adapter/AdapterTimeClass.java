package com.eagleteam.knigh.schedule.Adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.eagleteam.knigh.schedule.Object.TimeClass;
import com.eagleteam.knigh.schedule.R;

import java.util.List;

public class AdapterTimeClass extends RecyclerView.Adapter<AdapterTimeClass.ViewHolder> {
    private Context context;
    private List<TimeClass> listTimeClasses;

    public AdapterTimeClass(Context context, List<TimeClass> listTimeClasses) {
        this.context = context;
        this.listTimeClasses = listTimeClasses;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.layout_item_time, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        viewHolder.tvTiet.setText(String.valueOf(listTimeClasses.get(i).getTiet()));
        viewHolder.tvMuaHe.setText(listTimeClasses.get(i).getTgBatDauMuaHe() + " - " + listTimeClasses.get(i).getTgKetThucMuaHe());
        viewHolder.tvMuaDong.setText(listTimeClasses.get(i).getTgBatDauMuaDong() + " - " + listTimeClasses.get(i).getTgKetThucMuaDong());
    }

    @Override
    public int getItemCount() {
        return listTimeClasses.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView tvTiet, tvMuaDong, tvMuaHe;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTiet = itemView.findViewById(R.id.tvTiet);
            tvMuaHe = itemView.findViewById(R.id.tvMuaHe);
            tvMuaDong = itemView.findViewById(R.id.tvMuaDong);
        }
    }
}
