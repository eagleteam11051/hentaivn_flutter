package com.eagleteam.knigh.schedule.Fragment;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.eagleteam.knigh.schedule.Database.DatabaseSchedule;
import com.eagleteam.knigh.schedule.Object.Schedule;
import com.eagleteam.knigh.schedule.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import es.dmoral.toasty.Toasty;

public class FragmentAddNote extends Fragment implements View.OnClickListener{
    private EditText edtTitle, edtContent;
    private TextView tvDate;
    private Button btnConfirm, btnReset;
    private DatePickerDialog datePickerDialog;
    private DatabaseSchedule databaseSchedule;
    private Calendar calendar;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_addnote, container, false);

        calendar = Calendar.getInstance();
        databaseSchedule = new DatabaseSchedule(getActivity());
        datePickerDialog = new DatePickerDialog(getActivity(), AlertDialog.THEME_HOLO_LIGHT, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int date) {
                month = month+1;
                String strDate = year + "-" + month + "-" + date;
                Date day = new Date();
                try {
                    day = new SimpleDateFormat("yyyy-MM-dd").parse(strDate);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                tvDate.setText(new SimpleDateFormat("yyyy-MM-dd").format(day));
            }
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.setTitle("Chọn ngày");

        edtTitle = view.findViewById(R.id.edtTitle);
        edtContent = view.findViewById(R.id.edtContent);
        tvDate = view.findViewById(R.id.tvDate);
        btnConfirm = view.findViewById(R.id.btnConfirm);
        btnReset = view.findViewById(R.id.btnReset);
        tvDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datePickerDialog.show();
            }
        });
        btnConfirm.setOnClickListener(this);
        btnReset.setOnClickListener(this);
        return view;
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.btnConfirm){
            if (tvDate.getText().toString().trim().isEmpty() == false){
                String title = edtTitle.getText().toString().trim();
                String content = edtContent.getText().toString().trim();
                String date = tvDate.getText().toString().trim();
                Schedule schedule =  new Schedule(title, content, "", date, "", "", "", "Note", "");
                databaseSchedule.addNote(schedule);
                Toasty.success(getActivity(), "Thêm thành công", Toast.LENGTH_SHORT).show();
            }
        }
        if (view.getId() == R.id.btnReset){
            edtTitle.setText("");
            edtContent.setText("");
            tvDate.setText("");
            edtTitle.requestFocus();
        }
    }
}
