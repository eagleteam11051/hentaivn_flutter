package com.eagleteam.knigh.schedule.Adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.eagleteam.knigh.schedule.Object.Score;
import com.eagleteam.knigh.schedule.R;

import java.util.List;

public class AdapterScore extends RecyclerView.Adapter<AdapterScore.ViewHolder> {
    private Context context;
    private List<Score> listScores;

    public AdapterScore(Context context, List<Score> listScores) {
        this.context = context;
        this.listScores = listScores;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.layout_item_score, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
//        viewHolder.tvKT.setVisibility(View.VISIBLE);
//        viewHolder.tvKT1.setVisibility(View.VISIBLE);
        viewHolder.tvMonHoc.setText(listScores.get(i).getTenMon() + " - ");
        viewHolder.tvSoTinChi.setText(listScores.get(i).getSoTinChi() + " TC");
        viewHolder.tvCC.setText(listScores.get(i).getDiemCC());
//        if (listScores.get(i).getDiemKT().isEmpty()){
//            viewHolder.tvKT.setVisibility(View.GONE);
//            viewHolder.tvKT1.setVisibility(View.GONE);
//        }else{
//            viewHolder.tvKT.setText("KT");
//            viewHolder.tvKT1.setText(listScores.get(i).getDiemKT());
//        }
        viewHolder.tvTHI.setText(listScores.get(i).getDiemThi());
        viewHolder.tvTKHP.setText(listScores.get(i).getDiemTB());
        viewHolder.tvXL.setText(listScores.get(i).getXepLoai());
    }

    @Override
    public int getItemCount() {
        return listScores.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView tvMonHoc, tvSoTinChi, tvCC, tvKT, tvKT1, tvTHI, tvTKHP, tvXL;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvMonHoc = itemView.findViewById(R.id.tvMonHoc);
            tvSoTinChi = itemView.findViewById(R.id.tvSoTinChi);
            tvCC = itemView.findViewById(R.id.tvCC);
//            tvKT = itemView.findViewById(R.id.tvKT);
//            tvKT1 = itemView.findViewById(R.id.tvKT1);
            tvTHI = itemView.findViewById(R.id.tvTHI);
            tvTKHP = itemView.findViewById(R.id.tvTKHP);
            tvXL = itemView.findViewById(R.id.tvXL);
        }
    }
}
