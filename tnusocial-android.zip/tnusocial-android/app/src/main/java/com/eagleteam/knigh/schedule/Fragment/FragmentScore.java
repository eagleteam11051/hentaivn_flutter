package com.eagleteam.knigh.schedule.Fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.eagleteam.knigh.schedule.Adapter.AdapterScore;
import com.eagleteam.knigh.schedule.Database.DatabaseSchedule;
import com.eagleteam.knigh.schedule.Object.FilterScore;
import com.eagleteam.knigh.schedule.Object.Score;
import com.eagleteam.knigh.schedule.Object.Subject;
import com.eagleteam.knigh.schedule.R;
import com.eagleteam.knigh.schedule.Until.ConnectServer;
import com.eagleteam.knigh.schedule.Until.ParserJSON;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

import es.dmoral.toasty.Toasty;
import io.github.kobakei.materialfabspeeddial.FabSpeedDial;

public class FragmentScore extends Fragment implements  FabSpeedDial.OnMenuItemClickListener{
    private TextView tvMaSV, tvHoTen, tvTongTC, tvSTCXTN, tvSTCTL, tvDTBHS10, tvDTBHS4;
    private RecyclerView recyclerView;
    private SharedPreferences sharedPreferencesLogin, sharedPreferencesInfoScore;
    private DatabaseSchedule databaseSchedule;
    private ProgressDialog progressDialog;
    private FabSpeedDial fabSpeedDial;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_score, container, false);

        getActivity().setTitle("Tra cứu điểm");
        tvMaSV = view.findViewById(R.id.tvMaSV);
        tvHoTen = view.findViewById(R.id.tvHoTen);
        tvTongTC = view.findViewById(R.id.tvTongTC);
        tvSTCXTN = view.findViewById(R.id.tvSTCXTN);
        tvSTCTL = view.findViewById(R.id.tvSTCTL);
        tvDTBHS10 = view.findViewById(R.id.tvDTBHS10);
        tvDTBHS4 = view.findViewById(R.id.tvDTBHS4);
        recyclerView = view.findViewById(R.id.recyclerViewMark);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        databaseSchedule = new DatabaseSchedule(getActivity());
        progressDialog = new ProgressDialog(getActivity());
        sharedPreferencesLogin = getActivity().getSharedPreferences("config_login", getActivity().MODE_PRIVATE);
        sharedPreferencesInfoScore = getActivity().getSharedPreferences("config_infoscore", getActivity().MODE_PRIVATE);
        showScore();

        fabSpeedDial = view.findViewById(R.id.fabScore);


        fabSpeedDial.addOnMenuItemClickListener(this);

        return view;
    }
    private void showScore(){
        tvMaSV.setText(sharedPreferencesLogin.getString("MaSV", ""));
        tvHoTen.setText(sharedPreferencesLogin.getString("HoTen", ""));
        tvTongTC.setText("Tổng TC: " + sharedPreferencesInfoScore.getString("TongTC", ""));
        tvSTCXTN.setText("STC XTN: " + sharedPreferencesInfoScore.getString("STCTD", ""));
        tvSTCTL.setText("STC TL: " + sharedPreferencesInfoScore.getString("STCTLN", ""));
        tvDTBHS10.setText("ĐTB HS10: " + sharedPreferencesInfoScore.getString("DTBC", ""));
        tvDTBHS4.setText("ĐTB HS4: " + sharedPreferencesInfoScore.getString("DTBCQD", ""));
        List<Score> listScores = databaseSchedule.getListScore();
        recyclerView.setAdapter(new AdapterScore(getActivity(), listScores));
    }

    public boolean isNetworkConnected() {
        ConnectivityManager cm = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo() != null;
    }

    @Override
    public void onMenuItemClick(FloatingActionButton miniFab, @Nullable TextView label, int itemId) {
        if (itemId == R.id.itemUpdate){
            if (isNetworkConnected() == true){
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setMessage("Xác nhận cập nhật điểm?");
                builder.setCancelable(true);
                builder.setPositiveButton("Đồng ý", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        progressDialog.setMessage("Đang cập nhật điểm...");
                        progressDialog.setCancelable(false);
                        progressDialog.show();
                        new ConnectServer().getJSONScore(getActivity(), sharedPreferencesLogin.getString("access-token", ""), new ConnectServer.VolleyCallBack() {
                            @Override
                            public void getJSON(String json) throws JSONException {
                                SharedPreferences.Editor editor = sharedPreferencesInfoScore.edit();
                                ParserJSON parserJSON = new ParserJSON(json);
                                List<String> listInfosScore = parserJSON.getInfoScore();
                                List<Subject> listSubjects = parserJSON.getListSubjectsScore();
                                List<Score> listScores = parserJSON.getListScores(listSubjects);
                                if (listInfosScore.size() == 0 || listSubjects.size() == 0 || listScores.size() == 0){
                                    Toasty.error(getActivity(), "Cập nhật điểm thất bại!", Toast.LENGTH_SHORT).show();
                                } else {
                                    databaseSchedule.deleteScore();
                                    editor.putString("TongTC", listInfosScore.get(0));
                                    editor.putString("STCTD", listInfosScore.get(1));
                                    editor.putString("STCTLN", listInfosScore.get(2));
                                    editor.putString("DTBC", listInfosScore.get(3));
                                    editor.putString("DTBCQD", listInfosScore.get(4));
                                    editor.putString("SoMonKhongDat", listInfosScore.get(5));
                                    editor.putString("SoTCKhongDat", listInfosScore.get(6));
                                    editor.commit();;
                                    databaseSchedule.addListScores(listScores);
                                    showScore();
                                    Toasty.success(getActivity(), "Cập nhật điểm thành công!", Toast.LENGTH_SHORT).show();
                                }
                                progressDialog.dismiss();

                            }
                        });
                    }
                });
                builder.setNegativeButton("Hủy bỏ", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
            else Toasty.warning(getActivity(), "Không có kết nối mạng!", Toast.LENGTH_SHORT).show();
        }
        if (itemId == R.id.itemFilter){
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setCancelable(true);
            View view = LayoutInflater.from(getActivity()).inflate(R.layout.layout_dialog_score, null, false);
            final List<String> listFilter = initListFilter();
            ListView listViewFilter = view.findViewById(R.id.listViewFilterScore);
            listViewFilter.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, listFilter));
            builder.setView(view);
            builder.setPositiveButton("Hủy bỏ", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            });
            final AlertDialog alertDialog = builder.create();
            listViewFilter.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    List<Score> listScores = databaseSchedule.getListScore();
                    if (listFilter.get(i).equals("Tất cả")){
                        recyclerView.setAdapter(new AdapterScore(getActivity(), listScores));
                    }else{
                        List<Score> listScoreFilter = new FilterScore(listScores).getListScoresByRank(listFilter.get(i).substring(9));
                        recyclerView.setAdapter(new AdapterScore(getActivity(), listScoreFilter));
                    }
                    alertDialog.dismiss();
                }
            });
            alertDialog.show();

        }
    }

    public List<String> initListFilter(){
        List<String> listFilter = new ArrayList<>();
        listFilter.add("Tất cả");
        listFilter.add("Xếp loại A");
        listFilter.add("Xếp loại B");
        listFilter.add("Xếp loại C");
        listFilter.add("Xếp loại D");
        listFilter.add("Xếp loại F");
        return listFilter;
    }
}
