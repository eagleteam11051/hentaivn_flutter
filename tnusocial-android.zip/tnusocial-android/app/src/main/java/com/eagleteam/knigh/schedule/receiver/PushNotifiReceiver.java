package com.eagleteam.knigh.schedule.receiver;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.provider.Settings;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.eagleteam.knigh.schedule.Activity.MainActivity;
import com.eagleteam.knigh.schedule.Database.DatabaseSchedule;
import com.eagleteam.knigh.schedule.Object.Schedule;
import com.eagleteam.knigh.schedule.R;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;


public class PushNotifiReceiver extends BroadcastReceiver {
    private static final int TIME_VIBRATE = 1000;
    //ahihi update file
    DatabaseSchedule databaseSchedule;
    List<Schedule> schedules = new ArrayList<>();
    String contentText = "";


    private void createNotificationChannel(Context context) {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            String name = "Tnu_Social";
            String description = "Schedule_View";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel("id_channel", name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager mNotificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

            mNotificationManager.createNotificationChannel(channel);
        }
    }
    public class CustomComparator implements Comparator<Schedule> {
        @Override
        public int compare(Schedule o1, Schedule o2) {
            return o2.getThoiGian().compareTo(o1.getThoiGian());
        }
    }
    private void initDatabase(Context context) {
        databaseSchedule = new DatabaseSchedule(context);
        Date date = new Date(System.currentTimeMillis()+86400000);// lay ngay hien tai cong them 1 ngay => ngay mai
        this.schedules = databaseSchedule.getListScheduleByDate(date);
        Collections.sort(schedules,new CustomComparator());
        Log.e("SCHEDULE", String.valueOf(databaseSchedule.getListScheduleByDate(date).size()));
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.e("NOTIFI","HIHI");
        createNotificationChannel(context);
        initDatabase(context);
        if(schedules.isEmpty()) {
            this.contentText = "Ngày mai bạn rảnh ^_^";
            Intent notificationIntent = new Intent(context, MainActivity.class);
            notificationIntent
                    .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            int requestID = (int) System.currentTimeMillis();
            PendingIntent contentIntent = PendingIntent
                    .getActivity(context, requestID, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
            NotificationCompat.Builder builder =
                    new NotificationCompat.Builder(context)
                            .setStyle(new NotificationCompat.BigTextStyle().bigText(contentText))
                            .setChannelId("id_channel")
                            .setSmallIcon(R.mipmap.ic_logo_round)
                            .setContentTitle("Ngày mai")
                            .setContentText(contentText)
                            .setSound(Settings.System.DEFAULT_NOTIFICATION_URI)
                            .setDefaults(Notification.DEFAULT_SOUND)
                            .setAutoCancel(false)
                            .setPriority(6)
                            .setVibrate(new long[]{TIME_VIBRATE, TIME_VIBRATE, TIME_VIBRATE, TIME_VIBRATE,
                                    TIME_VIBRATE})
                            .setContentIntent(contentIntent);
            NotificationManager notificationManager =
                    (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.notify(0, builder.build());
        }else{
            for(int i=0;i<this.schedules.size();i++){
                Schedule schedule = this.schedules.get(i);
                contentText = "";
                if(schedule.getSoBaoDanh().isEmpty()){
                    contentText += "Môn học: " + schedule.getTenMon();
                    contentText += "\nThời gian: " + schedule.getThoiGian();
                    contentText += "\nĐịa điểm: " + schedule.getDiaDiem();
                    contentText += "\nGiáo viên: " + schedule.getGiaoVien();
                }else if(!schedule.getThoiGian().isEmpty()){
                    contentText += "Môn thi: " + schedule.getTenMon();
                    contentText += "\nSBD: " + schedule.getSoBaoDanh();
                    contentText += "\nThời gian: " + schedule.getThoiGian();
                    contentText += "\nĐịa điểm: " + schedule.getDiaDiem();
                    contentText += "\nHình thức: " + schedule.getHinhThuc();
                }
                if(schedule.getThoiGian().isEmpty()){
                    contentText += "Tiêu đề: " + schedule.getMaMon();
                    contentText += "\nNội dung: " + schedule.getTenMon();
                }
                //push
                Intent notificationIntent = new Intent(context, MainActivity.class);
                notificationIntent
                        .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                int requestID = (int) System.currentTimeMillis();
                PendingIntent contentIntent = PendingIntent
                        .getActivity(context, requestID, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                NotificationCompat.Builder builder =
                        new NotificationCompat.Builder(context)
                                .setStyle(new NotificationCompat.BigTextStyle().bigText(contentText))
                                .setChannelId("id_channel")
                                .setSmallIcon(R.mipmap.ic_logo_round)
                                .setContentTitle("Ngày mai")
                                .setContentText(contentText)
                                .setSound(Settings.System.DEFAULT_NOTIFICATION_URI)
                                .setDefaults(Notification.DEFAULT_SOUND)
                                .setAutoCancel(false)
                                .setPriority(6)
                                .setVibrate(new long[]{TIME_VIBRATE, TIME_VIBRATE, TIME_VIBRATE, TIME_VIBRATE,
                                        TIME_VIBRATE})
                                .setContentIntent(contentIntent);
                NotificationManager notificationManager =
                        (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                notificationManager.notify(i, builder.build());
            }
        }
    }
}
