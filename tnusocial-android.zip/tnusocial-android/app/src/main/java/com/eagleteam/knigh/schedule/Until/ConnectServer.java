package com.eagleteam.knigh.schedule.Until;

import android.content.Context;
import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;

import java.util.HashMap;
import java.util.Map;

public class ConnectServer {
    public void getJSONLogin(Context context, final String username, final String password, final VolleyCallBack volleyCallBack){
        String urlLogin = "https://sqt-ictu.herokuapp.com/api.php?action=login";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, urlLogin, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    volleyCallBack.getJSON(response.toString());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();
                map.put("username", username);
                map.put("password", password);
                return map;
            }
        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(30000* DefaultRetryPolicy.DEFAULT_TIMEOUT_MS, 0, 0));
        Volley.newRequestQueue(context).add(stringRequest);
    }
    public void getJSONSemester(Context context , final String access_token, final VolleyCallBack volleyCallBack){
        String urlSemester = "https://sqt-ictu.herokuapp.com/api.php?action=semester";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, urlSemester, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    volleyCallBack.getJSON(response.toString());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("consemester", error.toString());
            }
        }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();
                map.put("access-token", access_token);
                return map;
            }
        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(30000* DefaultRetryPolicy.DEFAULT_TIMEOUT_MS, 0, 0));
        Volley.newRequestQueue(context).add(stringRequest);
    }
    public void getJSONTimeTable(Context context , final String access_token, final String semester, final VolleyCallBack volleyCallBack){
        String urlTimeTable = "https://sqt-ictu.herokuapp.com/api.php?action=time-table";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, urlTimeTable, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    volleyCallBack.getJSON(response.toString());
                    Log.d("TimeTable", response.toString());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("Error_TimeTable", error.toString());
            }
        }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();
                map.put("access-token", access_token);
                return map;
            }

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();
                map.put("semester", semester);
                return map;
            }
        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(30000* DefaultRetryPolicy.DEFAULT_TIMEOUT_MS, 0, 0));
        Volley.newRequestQueue(context).add(stringRequest);
    }
    public void getJSONExamTable(Context context , final String access_token, final String semester, final VolleyCallBack volleyCallBack){
        String urlExamTable = "https://sqt-ictu.herokuapp.com/api.php?action=exam-table";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, urlExamTable, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    volleyCallBack.getJSON(response.toString());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("Error_ExamTable", error.toString());
            }
        }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();
                map.put("access-token", access_token);
                return map;
            }

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();
                map.put("semester", semester);
                return map;
            }
        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(30000* DefaultRetryPolicy.DEFAULT_TIMEOUT_MS, 0, 0));
        Volley.newRequestQueue(context).add(stringRequest);
    }
    public void getJSONProfileStudent(Context context , final String access_token, final VolleyCallBack volleyCallBack){
        String urlProfile = "https://sqt-ictu.herokuapp.com/api.php?action=profile";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, urlProfile, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    volleyCallBack.getJSON(response);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();
                map.put("access-token", access_token);
                return map;
            }
        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(30000* DefaultRetryPolicy.DEFAULT_TIMEOUT_MS, 0, 0));
        Volley.newRequestQueue(context).add(stringRequest);
    }
    public void getJSONScore(Context context , final String access_token, final VolleyCallBack volleyCallBack){
        String urlScore = "https://sqt-ictu.herokuapp.com/api.php?action=mark";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, urlScore, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    volleyCallBack.getJSON(response.toString());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("ERROR_getJSONScore", error.toString());
            }
        }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();
                map.put("access-token", access_token);
                return map;
            }
        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(30000* DefaultRetryPolicy.DEFAULT_TIMEOUT_MS, 0, 0));
        Volley.newRequestQueue(context).add(stringRequest);
    }
    public interface VolleyCallBack{
        void getJSON(String json) throws JSONException;
    }
}
