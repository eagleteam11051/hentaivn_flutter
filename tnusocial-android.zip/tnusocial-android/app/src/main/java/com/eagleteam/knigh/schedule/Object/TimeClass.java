package com.eagleteam.knigh.schedule.Object;

public class TimeClass {
    private int tiet;
    private String tgBatDauMuaHe, tgKetThucMuaHe;
    private String tgBatDauMuaDong, tgKetThucMuaDong;

    public TimeClass(int tiet, String tgBatDauMuaHe, String tgKetThucMuaHe, String tgBatDauMuaDong, String tgKetThucMuaDong) {
        this.tiet = tiet;
        this.tgBatDauMuaHe = tgBatDauMuaHe;
        this.tgKetThucMuaHe = tgKetThucMuaHe;
        this.tgBatDauMuaDong = tgBatDauMuaDong;
        this.tgKetThucMuaDong = tgKetThucMuaDong;
    }

    public int getTiet() {
        return tiet;
    }

    public void setTiet(int tiet) {
        this.tiet = tiet;
    }

    public String getTgBatDauMuaHe() {
        return tgBatDauMuaHe;
    }

    public void setTgBatDauMuaHe(String tgBatDauMuaHe) {
        this.tgBatDauMuaHe = tgBatDauMuaHe;
    }

    public String getTgKetThucMuaHe() {
        return tgKetThucMuaHe;
    }

    public void setTgKetThucMuaHe(String tgKetThucMuaHe) {
        this.tgKetThucMuaHe = tgKetThucMuaHe;
    }

    public String getTgBatDauMuaDong() {
        return tgBatDauMuaDong;
    }

    public void setTgBatDauMuaDong(String tgBatDauMuaDong) {
        this.tgBatDauMuaDong = tgBatDauMuaDong;
    }

    public String getTgKetThucMuaDong() {
        return tgKetThucMuaDong;
    }

    public void setTgKetThucMuaDong(String tgKetThucMuaDong) {
        this.tgKetThucMuaDong = tgKetThucMuaDong;
    }
}
