package com.eagleteam.knigh.schedule.Adapter;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.TextView;

import com.eagleteam.knigh.schedule.Database.DatabaseSchedule;
import com.eagleteam.knigh.schedule.Object.Schedule;
import com.eagleteam.knigh.schedule.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import es.dmoral.toasty.Toasty;

public class AdapterNote extends RecyclerView.Adapter<AdapterNote.ViewHolder> {
    private Context context;
    private List<Schedule> listSchedules;
    private DatabaseSchedule databaseSchedule;

    public AdapterNote(Context context, List<Schedule> listSchedules, DatabaseSchedule databaseSchedule) {
        this.context = context;
        this.listSchedules = listSchedules;
        this.databaseSchedule = databaseSchedule;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.layout_item_note, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder viewHolder, final int i) {
        viewHolder.tvDate.setText("Ngày: " + listSchedules.get(i).getNgay());
        viewHolder.tvTitle.setText("Tiêu đề: " + listSchedules.get(i).getMaMon());
        viewHolder.tvContent.setText("Nội dung: " + listSchedules.get(i).getTenMon());
        viewHolder.tvOption.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu = new PopupMenu(context, viewHolder.tvOption);
                popupMenu.inflate(R.menu.menu_option_note);
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        if (menuItem.getItemId() == R.id.itemDelete){
                            databaseSchedule.deleteNote(listSchedules.get(i).getId());
                            listSchedules.remove(i);
                            notifyDataSetChanged();
                            Toasty.success(context, "Xóa thành công", 500).show();
                        }
                        if (menuItem.getItemId() == R.id.itemUpdate){
                            initDialogUpdateNote(i);
                        }
                        return false;
                    }
                });
                popupMenu.show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return listSchedules.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView tvDate, tvTitle, tvContent, tvOption;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvDate = itemView.findViewById(R.id.tvDate);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvContent = itemView.findViewById(R.id.tvContent);
            tvOption = itemView.findViewById(R.id.tvOption);
        }
    }
    public void initDialogUpdateNote(final int pos){
        AlertDialog.Builder builderDialog = new AlertDialog.Builder(context);
        builderDialog.setCancelable(false);
        builderDialog.setTitle("Thêm ghi chú");
        View viewDialog = LayoutInflater.from(context).inflate(R.layout.layout_dialog_addnote, null, false);
        Calendar calendar = Calendar.getInstance();
        final EditText edtTitle, edtContent;
        final TextView tvDate;
        edtTitle = viewDialog.findViewById(R.id.edtTitle);
        edtContent = viewDialog.findViewById(R.id.edtContent);
        tvDate = viewDialog.findViewById(R.id.tvDate);
        edtTitle.setText(listSchedules.get(pos).getMaMon());
        edtContent.setText(listSchedules.get(pos).getTenMon());
        tvDate.setText(listSchedules.get(pos).getNgay());
        final DatePickerDialog datePickerDialog = new DatePickerDialog(context, AlertDialog.THEME_HOLO_LIGHT, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int date) {
                month = month + 1;
                String strDate = year + "-" + month + "-" + date;
                Date day = new Date();
                try {
                    day = new SimpleDateFormat("yyyy-MM-dd").parse(strDate);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                tvDate.setText(new SimpleDateFormat("yyyy-MM-dd").format(day));
            }
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        tvDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datePickerDialog.show();
            }
        });
        builderDialog.setView(viewDialog);
        builderDialog.setPositiveButton("Cập nhật", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (edtTitle.getText().toString().trim().isEmpty() == false
                        && edtContent.getText().toString().trim().isEmpty() == false
                        && tvDate.getText().toString().isEmpty() == false){
                    String title = edtTitle.getText().toString().trim();
                    String content = edtContent.getText().toString().trim();
                    String date = tvDate.getText().toString().trim();
                    Schedule schedule = new Schedule(listSchedules.get(pos).getId(), title, content, "", date, "", "", "", "Note", "");
                    databaseSchedule.updateNote(schedule);
                    listSchedules.set(pos, schedule);
                    notifyDataSetChanged();
                    Toasty.success(context, "Cập nhật thành công", 500).show();
                }
                else
                    Toasty.error(context, "Cập nhật thất bại", 500).show();
            }
        });
        builderDialog.setNegativeButton("Hủy bỏ", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        AlertDialog alertDialog = builderDialog.create();
        alertDialog.show();
    }
}
