#include <stdio.h>

// so luong so trong day
int n;

// mang cac so trong day
int a[20];

// so luong cach xep trong 1 day (KQ cua 1 test)
int count;

// mang cac so sap xep de thoa man yeu cau
int c[20];

/* mang danh dau so da duoc sap xep chua. 
* v[i] = 1 => a[i] da duoc xep vao day vong tron, 
* v[i] = 0 => a[i] chua duoc chua xep vao day vong tron.
*/
int v[20];

/*
* Mang check cac so nguyen to. 
* prime[i] = 0 => i KHONG la so nguyen to
* prime[i] = 1 => i la so nguyen to
* Do cac so p <= 50 nen tong 2 so lien tiep <= 100 nen chi can sinh 10 so la du.
* Viec sinh day nay rat don gian ^^.
*/

int prime[101] = {
	0,
	0,1,1,0,1,0,1,0,0,0,
	1,0,1,0,0,0,1,0,1,0,
	0,0,1,0,0,0,0,0,1,0,
	1,0,0,0,0,0,1,0,0,0,
	1,0,1,0,0,0,1,0,0,0,
	0,0,1,0,0,0,0,0,1,0,
	1,0,0,0,0,0,1,0,0,0,
	1,0,1,0,0,0,0,0,1,0,
	0,0,1,0,0,0,0,0,1,0,
	0,0,0,0,0,0,1,0,0,0,
};

/*
* Chay thuat toan quay lui tai vi tri u.
*/
void run(int u)
{
	int s = c[u-1] + c[0];
	if(u == n && prime[s] == 1) 
	{
		count++; 
		return;
	}
	for(int i = 0; i < n; i++)
	{	
		s = c[u-1] + a[i];
		// neu a[i] da xep hoac tong 2 so lien tiep khong nguyen to thi bo qua
		if(v[i] || prime[s] == 0) continue;
		
		// danh dau a[i] da xep vao vong tron
		v[i]=1;

		// xep a[i] vao day c
		c[u]=a[i];

		// tiep tuc xep vi tri tiep theo
		run(u+1);

		// tra lai gia tri de quay lui lai buoc truoc do.
		c[u]=0;
		v[i]=0;
	}
}

int main()
{
	int T;
	scanf("%d", &T);
	for(int t = 1; t <= T; t++)
	{
		scanf("%d", &n);
		count = 0;
		for(int i=0;i<n;i++)
		{
			scanf("%d", &a[i]);
			v[i]=0;
			c[i]=0;
		}
		v[1]=1;
		c[0] = a[1];
		run(1);
		printf("%d\n", count);
	}
	return 0;
}
