# TnuSocial-Android

Project Xem lịch học, lịch thi và các tiện ích khác cho sinh viên 